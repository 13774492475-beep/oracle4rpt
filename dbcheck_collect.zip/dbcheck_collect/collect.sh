#!/bin/bash

# 定义基础目录和相关子目录
BASE_DIR="/oracle/dbcheck_collect"
DBCHECK_DIR="$BASE_DIR/dbcheck"
OSCHECK_LINUX_DIR="$BASE_DIR/oscheck_for_linux"
OSCHECK_AIX_DIR="$BASE_DIR/oscheck_for_aix"
LOG_DIR="$BASE_DIR/log"
DATA_COLLECT_DIR="$BASE_DIR/data_collect"

# 创建日志和数据目录，并设置权限
mkdir -p "$LOG_DIR" "$DATA_COLLECT_DIR"
chmod -R 777 "$BASE_DIR"

# 初始化日志文件，包含时间戳以避免重名
LOG_FILE="$LOG_DIR/execution_$(date +%Y%m%d_%H%M%S).log"

# 获取主机名
HOSTNAME=$(hostname)

# 检查操作系统类型并设置相应的目录
OS_TYPE=$(uname)
echo "正在检查操作系统类型..." | tee -a "$LOG_FILE"
case "$OS_TYPE" in
    "Linux")
        echo "正在Linux系统上运行。" | tee -a "$LOG_FILE"
        OSCHECK_DIR="$OSCHECK_LINUX_DIR"
        ;;
    "AIX")
        echo "正在AIX系统上运行。" | tee -a "$LOG_FILE"
        OSCHECK_DIR="$OSCHECK_AIX_DIR"
        ;;
    *)
        echo "不支持的操作系统: $OS_TYPE" | tee -a "$LOG_FILE"
        exit 1
        ;;
esac

# 定义一个函数以指定用户身份在特定目录中执行脚本
run_as_user_in_dir() {
    local user="$1"
    local script="$2"
    local work_dir="$3"
    local instance_dir="$4"
    local oracle_sid="$5"

    echo "正在以用户 $user 在目录 $work_dir 中执行脚本 $script" | tee -a "$LOG_FILE"
    
    # 使用 su - 切换到指定用户，并在切换后导入环境变量
    su - "$user" -c "
    export ORACLE_SID=$oracle_sid
    cd $work_dir && bash $script
    " >> "$instance_dir/execution.log" 2>&1
    
    # 如果脚本执行失败，则退出并记录日志
    if [ $? -ne 0 ]; then
        echo "执行 $script 失败。" | tee -a "$LOG_FILE"
        exit 1
    fi

    # 立即移动脚本生成的文件到实例目录
    mv $work_dir/*.txt $work_dir/*.csv $instance_dir 2>/dev/null
}

# 创建用于存储数据的时间戳目录，并命名为带主机名前缀的目录
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
DATA_DIR="${HOSTNAME}_data_$TIMESTAMP"
DATA_TIMESTAMP_DIR="$DATA_COLLECT_DIR/$DATA_DIR"
mkdir -p "$DATA_TIMESTAMP_DIR/os_$HOSTNAME"

# 执行操作系统巡检
echo "正在执行操作系统巡检..." | tee -a "$LOG_FILE"
for script in "$OSCHECK_DIR"/*.sh; do
    if [[ -x "$script" ]]; then
        echo "执行 $script..." | tee -a "$LOG_FILE"
        (cd "$OSCHECK_DIR" && bash "$script") >> "$LOG_FILE" 2>&1
        if [ $? -eq 0 ]; then
            echo "已执行 $script" | tee -a "$LOG_FILE"
        else
            echo "执行 $script 失败。" | tee -a "$LOG_FILE"
            exit 1
        fi
    else
        echo "跳过 $script （不可执行）" | tee -a "$LOG_FILE"
    fi
done

# 将OS检查结果移动到os_$HOSTNAME目录
mv "$OSCHECK_DIR"/*.txt "$OSCHECK_DIR"/*.csv "$DATA_TIMESTAMP_DIR/os_$HOSTNAME" 2>/dev/null

# 检查是否为RAC集群
echo "正在检查RAC集群..." | tee -a "$LOG_FILE"
IS_RAC=$(ps -ef | grep asm_smon_+ASM | grep -v grep)
IS_RAC_CLUSTER=false

if [[ -n "$IS_RAC" ]]; then
    IS_RAC_CLUSTER=true
    echo "检测到RAC集群。" | tee -a "$LOG_FILE"
else
    echo "未检测到RAC集群。" | tee -a "$LOG_FILE"
fi

# 自动获取数据库实例
echo "正在获取数据库实例..." | tee -a "$LOG_FILE"
ps -ef | grep ora_smon_ | grep -v grep | awk -F smon_ '{print $2}' > "$BASE_DIR/env_db_instances"
if [[ "$IS_RAC_CLUSTER" == true ]]; then
    ps -ef | grep asm_smon_ | grep -v grep | awk -F smon_ '{print $2}' > "$BASE_DIR/env_gi_instances"
fi

# 获取数据库版本
DB_VERSION=$(su - oracle <<EOF | awk '/Release/{print $3}'
export ORACLE_SID=$(ps -ef | grep ora_smon_ | grep -v grep | awk -F smon_ '{print $2}' | head -n 1)
sqlplus -v
exit
EOF
)

if [[ -n "$DB_VERSION" ]]; then
    echo "数据库版本: $DB_VERSION" | tee -a "$LOG_FILE"
else
    echo "无法获取数据库版本。" | tee -a "$LOG_FILE"
    exit 1
fi

# 根据数据库版本设置脚本目录
case "$DB_VERSION" in
    10.*)
        DBCHECK_VERSION_DIR="$DBCHECK_DIR/10g"
        ;;
    11.2.0.4.0)
        DBCHECK_VERSION_DIR="$DBCHECK_DIR/11g"
        ;;
    19.0.0.0.0)
        DBCHECK_VERSION_DIR="$DBCHECK_DIR/19c"
        ;;
    *)
        echo "不支持的数据库版本: $DB_VERSION" | tee -a "$LOG_FILE"
        exit 1
        ;;
esac

# 定义数据库检查函数
run_db_checks() {
    local instance="$1"
    local dbname=$(echo "$instance" | awk '{print toupper($0)}')
    local instance_dir="$DATA_TIMESTAMP_DIR/dbname_$instance"
    
    # 创建数据库实例目录
    mkdir -p "$instance_dir"

    echo "执行数据库巡检：实例 $instance, 用户 oracle" | tee -a "$LOG_FILE"
    export ORACLE_SID="$instance"
    
    if [[ "$IS_RAC_CLUSTER" == true ]]; then
        for script in "$DBCHECK_VERSION_DIR/crs_lms.sh" "$DBCHECK_VERSION_DIR/crs_stats.sh"; do
            if [[ "$script" == "$DBCHECK_VERSION_DIR/crs_lms.sh" ]]; then
                run_as_user_in_dir "root" "$script" "$DBCHECK_VERSION_DIR" "$instance_dir" "$instance"
                echo "已执行 $script (以root用户)" | tee -a "$LOG_FILE"
            else
                run_as_user_in_dir "grid" "$script" "$DBCHECK_VERSION_DIR" "$instance_dir" "$instance"
                echo "已执行 $script (以grid用户)" | tee -a "$LOG_FILE"
            fi
        done
    fi

    for script in "$DBCHECK_VERSION_DIR"/*.sh; do
        case "$script" in
            "$DBCHECK_VERSION_DIR/crs_lms.sh" | "$DBCHECK_VERSION_DIR/crs_stats.sh")
                # 已在RAC检查中处理
                ;;
            *)
                echo "正在以 oracle 用户执行 $script" | tee -a "$LOG_FILE"
                run_as_user_in_dir "oracle" "$script" "$DBCHECK_VERSION_DIR" "$instance_dir" "$instance"
                echo "已执行 $script" | tee -a "$LOG_FILE"
                ;;
        esac
    done
}

# 执行数据库检查
echo "正在执行数据库检查脚本..." | tee -a "$LOG_FILE"
while IFS= read -r instance; do
    run_db_checks "$instance"
done < "$BASE_DIR/env_db_instances"

# 检查生成的文件
echo "检查生成的文件..." | tee -a "$LOG_FILE"
if [ "$(find "$DATA_TIMESTAMP_DIR" -type f \( -name "*.csv" -o -name "*.txt" \) | wc -l)" -eq 0 ]; then
    echo "未找到生成的文件。" | tee -a "$LOG_FILE"
    exit 1
fi

# 压缩数据目录，并在压缩包文件名中添加主机名作为前缀
echo "压缩数据目录..." | tee -a "$LOG_FILE"
cd "$DATA_COLLECT_DIR"
TAR_FILE="${HOSTNAME}_data_$TIMESTAMP.tar"
if tar -cvf "$TAR_FILE" "$DATA_DIR" >> "$LOG_FILE" 2>&1; then
    echo "压缩完成：$TAR_FILE" | tee -a "$LOG_FILE"
else
    echo "压缩失败。" | tee -a "$LOG_FILE"
    exit 1
fi

# 清理临时数据
rm -rf "$DATA_TIMESTAMP_DIR"

# 输出完成信息
echo "执行完成。" | tee -a "$LOG_FILE"

